﻿namespace CreateClassFromDatabaseTable
{
    partial class frmClassAndProcGenerator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmClassAndProcGenerator));
            this.btnClose = new System.Windows.Forms.Button();
            this.txtClassCode = new System.Windows.Forms.TextBox();
            this.btnCreateClass = new System.Windows.Forms.Button();
            this.cboSQLServers = new System.Windows.Forms.ComboBox();
            this.cboDatabases = new System.Windows.Forms.ComboBox();
            this.cboTables = new System.Windows.Forms.ComboBox();
            this.optSQL = new System.Windows.Forms.RadioButton();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtSQLUserName = new System.Windows.Forms.TextBox();
            this.txtStoredProc = new System.Windows.Forms.TextBox();
            this.btnCopyToClipboardStoredProc = new System.Windows.Forms.Button();
            this.btnCopyToClipboardClass = new System.Windows.Forms.Button();
            this.btnCreateStoredProc = new System.Windows.Forms.Button();
            this.grbClassOption = new System.Windows.Forms.GroupBox();
            this.optCSharp = new System.Windows.Forms.RadioButton();
            this.optVB = new System.Windows.Forms.RadioButton();
            this.txtStoredProcPrefix = new System.Windows.Forms.TextBox();
            this.txtVerbWord = new System.Windows.Forms.TextBox();
            this.txtSQLString = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.optWindows = new System.Windows.Forms.RadioButton();
            this.ttpfrmMain = new System.Windows.Forms.ToolTip(this.components);
            this.btnCopySQLStringToClipboard = new System.Windows.Forms.Button();
            this.grbClassOption.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(481, 408);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(84, 26);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtClassCode
            // 
            this.txtClassCode.AcceptsReturn = true;
            this.txtClassCode.AcceptsTab = true;
            this.txtClassCode.Location = new System.Drawing.Point(15, 222);
            this.txtClassCode.Margin = new System.Windows.Forms.Padding(2);
            this.txtClassCode.Multiline = true;
            this.txtClassCode.Name = "txtClassCode";
            this.txtClassCode.Size = new System.Drawing.Size(251, 181);
            this.txtClassCode.TabIndex = 1;
            this.txtClassCode.WordWrap = false;
            // 
            // btnCreateClass
            // 
            this.btnCreateClass.Location = new System.Drawing.Point(15, 188);
            this.btnCreateClass.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.btnCreateClass.Name = "btnCreateClass";
            this.btnCreateClass.Size = new System.Drawing.Size(114, 27);
            this.btnCreateClass.TabIndex = 4;
            this.btnCreateClass.Text = "Create Class";
            this.btnCreateClass.UseVisualStyleBackColor = true;
            this.btnCreateClass.Click += new System.EventHandler(this.btnCreateClass_Click);
            // 
            // cboSQLServers
            // 
            this.cboSQLServers.FormattingEnabled = true;
            this.cboSQLServers.Location = new System.Drawing.Point(15, 17);
            this.cboSQLServers.Margin = new System.Windows.Forms.Padding(2);
            this.cboSQLServers.Name = "cboSQLServers";
            this.cboSQLServers.Size = new System.Drawing.Size(252, 27);
            this.cboSQLServers.Sorted = true;
            this.cboSQLServers.TabIndex = 5;
            this.ttpfrmMain.SetToolTip(this.cboSQLServers, "Select SQL Server");
            this.cboSQLServers.SelectedIndexChanged += new System.EventHandler(this.cboSQLServers_SelectedIndexChanged);
            this.cboSQLServers.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboSQLServers_KeyPress);
            this.cboSQLServers.Leave += new System.EventHandler(this.cboSQLServers_Leave);
            // 
            // cboDatabases
            // 
            this.cboDatabases.FormattingEnabled = true;
            this.cboDatabases.Location = new System.Drawing.Point(15, 49);
            this.cboDatabases.Margin = new System.Windows.Forms.Padding(2);
            this.cboDatabases.Name = "cboDatabases";
            this.cboDatabases.Size = new System.Drawing.Size(252, 27);
            this.cboDatabases.Sorted = true;
            this.cboDatabases.TabIndex = 6;
            this.ttpfrmMain.SetToolTip(this.cboDatabases, "Select Database");
            this.cboDatabases.SelectedIndexChanged += new System.EventHandler(this.cboDatabases_SelectedIndexChanged);
            // 
            // cboTables
            // 
            this.cboTables.FormattingEnabled = true;
            this.cboTables.Location = new System.Drawing.Point(15, 81);
            this.cboTables.Margin = new System.Windows.Forms.Padding(2);
            this.cboTables.Name = "cboTables";
            this.cboTables.Size = new System.Drawing.Size(251, 27);
            this.cboTables.Sorted = true;
            this.cboTables.TabIndex = 8;
            this.ttpfrmMain.SetToolTip(this.cboTables, "Select Table");
            this.cboTables.SelectedIndexChanged += new System.EventHandler(this.cboTables_SelectedIndexChanged);
            // 
            // optSQL
            // 
            this.optSQL.Location = new System.Drawing.Point(200, 25);
            this.optSQL.Margin = new System.Windows.Forms.Padding(2);
            this.optSQL.Name = "optSQL";
            this.optSQL.Size = new System.Drawing.Size(56, 23);
            this.optSQL.TabIndex = 9;
            this.optSQL.Text = "SQL";
            this.optSQL.UseVisualStyleBackColor = true;
            this.optSQL.CheckedChanged += new System.EventHandler(this.optSQL_CheckedChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(150, 64);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(129, 27);
            this.txtPassword.TabIndex = 10;
            this.ttpfrmMain.SetToolTip(this.txtPassword, "Enter SQL Password");
            this.txtPassword.Visible = false;
            // 
            // txtSQLUserName
            // 
            this.txtSQLUserName.Location = new System.Drawing.Point(11, 64);
            this.txtSQLUserName.Margin = new System.Windows.Forms.Padding(2);
            this.txtSQLUserName.Name = "txtSQLUserName";
            this.txtSQLUserName.Size = new System.Drawing.Size(120, 27);
            this.txtSQLUserName.TabIndex = 11;
            this.ttpfrmMain.SetToolTip(this.txtSQLUserName, "Enter SQL User Name");
            this.txtSQLUserName.Visible = false;
            // 
            // txtStoredProc
            // 
            this.txtStoredProc.AcceptsReturn = true;
            this.txtStoredProc.AcceptsTab = true;
            this.txtStoredProc.Location = new System.Drawing.Point(271, 222);
            this.txtStoredProc.Margin = new System.Windows.Forms.Padding(2);
            this.txtStoredProc.Multiline = true;
            this.txtStoredProc.Name = "txtStoredProc";
            this.txtStoredProc.Size = new System.Drawing.Size(295, 181);
            this.txtStoredProc.TabIndex = 12;
            this.txtStoredProc.WordWrap = false;
            // 
            // btnCopyToClipboardStoredProc
            // 
            this.btnCopyToClipboardStoredProc.Location = new System.Drawing.Point(271, 406);
            this.btnCopyToClipboardStoredProc.Margin = new System.Windows.Forms.Padding(2);
            this.btnCopyToClipboardStoredProc.Name = "btnCopyToClipboardStoredProc";
            this.btnCopyToClipboardStoredProc.Size = new System.Drawing.Size(191, 28);
            this.btnCopyToClipboardStoredProc.TabIndex = 13;
            this.btnCopyToClipboardStoredProc.Text = "Copy Stored Proc To Clipboard";
            this.btnCopyToClipboardStoredProc.UseVisualStyleBackColor = true;
            this.btnCopyToClipboardStoredProc.Click += new System.EventHandler(this.btnCopyToClipboardStoredProc_Click);
            // 
            // btnCopyToClipboardClass
            // 
            this.btnCopyToClipboardClass.Location = new System.Drawing.Point(15, 406);
            this.btnCopyToClipboardClass.Margin = new System.Windows.Forms.Padding(2);
            this.btnCopyToClipboardClass.Name = "btnCopyToClipboardClass";
            this.btnCopyToClipboardClass.Size = new System.Drawing.Size(174, 28);
            this.btnCopyToClipboardClass.TabIndex = 14;
            this.btnCopyToClipboardClass.Text = "Copy Class To Clipboard";
            this.btnCopyToClipboardClass.UseVisualStyleBackColor = true;
            this.btnCopyToClipboardClass.Click += new System.EventHandler(this.btnCopyToClipboardCSharpClass_Click);
            // 
            // btnCreateStoredProc
            // 
            this.btnCreateStoredProc.Location = new System.Drawing.Point(272, 188);
            this.btnCreateStoredProc.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.btnCreateStoredProc.Name = "btnCreateStoredProc";
            this.btnCreateStoredProc.Size = new System.Drawing.Size(190, 27);
            this.btnCreateStoredProc.TabIndex = 15;
            this.btnCreateStoredProc.Text = "Create Stored Proc";
            this.btnCreateStoredProc.UseVisualStyleBackColor = true;
            this.btnCreateStoredProc.Click += new System.EventHandler(this.btnCreateStoredProc_Click);
            // 
            // grbClassOption
            // 
            this.grbClassOption.Controls.Add(this.optCSharp);
            this.grbClassOption.Controls.Add(this.optVB);
            this.grbClassOption.Location = new System.Drawing.Point(133, 176);
            this.grbClassOption.Margin = new System.Windows.Forms.Padding(2);
            this.grbClassOption.Name = "grbClassOption";
            this.grbClassOption.Padding = new System.Windows.Forms.Padding(2);
            this.grbClassOption.Size = new System.Drawing.Size(134, 39);
            this.grbClassOption.TabIndex = 16;
            this.grbClassOption.TabStop = false;
            // 
            // optCSharp
            // 
            this.optCSharp.Checked = true;
            this.optCSharp.Location = new System.Drawing.Point(74, 12);
            this.optCSharp.Margin = new System.Windows.Forms.Padding(2);
            this.optCSharp.Name = "optCSharp";
            this.optCSharp.Size = new System.Drawing.Size(56, 23);
            this.optCSharp.TabIndex = 18;
            this.optCSharp.TabStop = true;
            this.optCSharp.Text = "C#";
            this.optCSharp.UseVisualStyleBackColor = true;
            // 
            // optVB
            // 
            this.optVB.Location = new System.Drawing.Point(10, 12);
            this.optVB.Margin = new System.Windows.Forms.Padding(2);
            this.optVB.Name = "optVB";
            this.optVB.Size = new System.Drawing.Size(47, 23);
            this.optVB.TabIndex = 17;
            this.optVB.Text = "VB";
            this.optVB.UseVisualStyleBackColor = true;
            // 
            // txtStoredProcPrefix
            // 
            this.txtStoredProcPrefix.Location = new System.Drawing.Point(35, 116);
            this.txtStoredProcPrefix.Margin = new System.Windows.Forms.Padding(2);
            this.txtStoredProcPrefix.Name = "txtStoredProcPrefix";
            this.txtStoredProcPrefix.Size = new System.Drawing.Size(74, 27);
            this.txtStoredProcPrefix.TabIndex = 17;
            this.txtStoredProcPrefix.Text = "INISP_";
            this.ttpfrmMain.SetToolTip(this.txtStoredProcPrefix, "Stored Procedure Prefix");
            // 
            // txtVerbWord
            // 
            this.txtVerbWord.Location = new System.Drawing.Point(188, 116);
            this.txtVerbWord.Margin = new System.Windows.Forms.Padding(2);
            this.txtVerbWord.Name = "txtVerbWord";
            this.txtVerbWord.Size = new System.Drawing.Size(55, 27);
            this.txtVerbWord.TabIndex = 18;
            this.txtVerbWord.Text = "TODO";
            this.ttpfrmMain.SetToolTip(this.txtVerbWord, "Name Of Parameter to Specify CRUD to use");
            // 
            // txtSQLString
            // 
            this.txtSQLString.Location = new System.Drawing.Point(15, 148);
            this.txtSQLString.Name = "txtSQLString";
            this.txtSQLString.ReadOnly = true;
            this.txtSQLString.Size = new System.Drawing.Size(550, 27);
            this.txtSQLString.TabIndex = 19;
            this.ttpfrmMain.SetToolTip(this.txtSQLString, "SQL Connection String");
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.optWindows);
            this.groupBox1.Controls.Add(this.optSQL);
            this.groupBox1.Controls.Add(this.txtPassword);
            this.groupBox1.Controls.Add(this.txtSQLUserName);
            this.groupBox1.Location = new System.Drawing.Point(281, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(284, 96);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SQL Log In";
            // 
            // optWindows
            // 
            this.optWindows.Checked = true;
            this.optWindows.Location = new System.Drawing.Point(19, 26);
            this.optWindows.Name = "optWindows";
            this.optWindows.Size = new System.Drawing.Size(126, 23);
            this.optWindows.TabIndex = 10;
            this.optWindows.TabStop = true;
            this.optWindows.Text = "Windows Auth";
            this.optWindows.UseVisualStyleBackColor = true;
            this.optWindows.CheckedChanged += new System.EventHandler(this.optWindows_CheckedChanged);
            // 
            // btnCopySQLStringToClipboard
            // 
            this.btnCopySQLStringToClipboard.Location = new System.Drawing.Point(393, 116);
            this.btnCopySQLStringToClipboard.Margin = new System.Windows.Forms.Padding(2);
            this.btnCopySQLStringToClipboard.Name = "btnCopySQLStringToClipboard";
            this.btnCopySQLStringToClipboard.Size = new System.Drawing.Size(171, 27);
            this.btnCopySQLStringToClipboard.TabIndex = 21;
            this.btnCopySQLStringToClipboard.Text = "Copy SQL String To Clipboard";
            this.btnCopySQLStringToClipboard.UseVisualStyleBackColor = true;
            this.btnCopySQLStringToClipboard.Click += new System.EventHandler(this.btnCopySQLStringToClipboard_Click);
            // 
            // frmClassAndProcGenerator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 444);
            this.Controls.Add(this.btnCopySQLStringToClipboard);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtSQLString);
            this.Controls.Add(this.txtVerbWord);
            this.Controls.Add(this.txtStoredProcPrefix);
            this.Controls.Add(this.grbClassOption);
            this.Controls.Add(this.btnCreateStoredProc);
            this.Controls.Add(this.btnCopyToClipboardClass);
            this.Controls.Add(this.btnCopyToClipboardStoredProc);
            this.Controls.Add(this.txtStoredProc);
            this.Controls.Add(this.cboTables);
            this.Controls.Add(this.cboDatabases);
            this.Controls.Add(this.cboSQLServers);
            this.Controls.Add(this.btnCreateClass);
            this.Controls.Add(this.txtClassCode);
            this.Controls.Add(this.btnClose);
            this.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.Name = "frmClassAndProcGenerator";
            this.Text = "Class & MS SQL Stored Proc Generator";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.grbClassOption.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtClassCode;
        private System.Windows.Forms.Button btnCreateClass;
        private System.Windows.Forms.ComboBox cboSQLServers;
        private System.Windows.Forms.ComboBox cboDatabases;
        private System.Windows.Forms.ComboBox cboTables;
        private System.Windows.Forms.RadioButton optSQL;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtSQLUserName;
        private System.Windows.Forms.TextBox txtStoredProc;
        private System.Windows.Forms.Button btnCopyToClipboardStoredProc;
        private System.Windows.Forms.Button btnCopyToClipboardClass;
        private System.Windows.Forms.Button btnCreateStoredProc;
        private System.Windows.Forms.GroupBox grbClassOption;
        private System.Windows.Forms.RadioButton optCSharp;
        private System.Windows.Forms.RadioButton optVB;
        private System.Windows.Forms.TextBox txtStoredProcPrefix;
        private System.Windows.Forms.TextBox txtVerbWord;
        private System.Windows.Forms.TextBox txtSQLString;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton optWindows;
        private System.Windows.Forms.ToolTip ttpfrmMain;
        private System.Windows.Forms.Button btnCopySQLStringToClipboard;
    }
}

