﻿using System;
using System.Drawing;

using System.Windows.Forms;

namespace CreateClassFromDatabaseTable
{
    public partial class frmSplash : Form
    {
        public frmSplash()
        {
            InitializeComponent();
        }

    }
}
