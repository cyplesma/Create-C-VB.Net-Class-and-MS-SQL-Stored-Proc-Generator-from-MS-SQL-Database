﻿using System;
using System.Windows;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;
using System.Threading;

namespace CreateClassFromDatabaseTable
{
    public partial class frmClassAndProcGenerator : Form
    {

        ArrayList sSQLVersion;
        string sSelectedSQLVersion = "";
        string sNewLine = Environment.NewLine;
        string sTab = "\t";
        Thread threadSplash = null;
        public frmClassAndProcGenerator()
        {
            threadSplash = new Thread(new ThreadStart(SplashScreen));
            //Thread threadSplash = new Thread (new ThreadStart(SplashScreen));
            threadSplash.Start();
            InitializeComponent();

        }

        public void SplashScreen()
        {
            //Application.Run(new frmSplash());
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCreateClass_Click(object sender, EventArgs e)
        {
            //create a class for the given database.tablename and display it in the text box

            string sDBName = cboDatabases.Text.Trim();
            string sTableName = cboTables.Text.Trim();
            string sStoredProcPrefix = txtStoredProcPrefix.Text.Trim();
            string sVerbWord = txtVerbWord.Text.Trim();
            #region validate inputs
            if (sDBName.Length == 0)
            {
                MessageBox.Show("Select a database name.", "Missing Database Name", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cboDatabases.Focus();
                return;
            }
            if (sTableName.Length == 0)
            {
                MessageBox.Show("Select a table name.", "Missing Table Name", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cboTables.Focus();
                return;

            }
            if (sStoredProcPrefix.Length == 0)
            {
                MessageBox.Show("Enter a few characters for a Stored Proc Prefix.", "Missing Stored Proc Prefix", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtStoredProcPrefix.Focus();
                return;
            }
            if (sVerbWord.Length == 0)
            {
                MessageBox.Show("Enter a few characters for a Stored Proc Verb Word.", "Missing Stored Proc Verb Word", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtVerbWord.Focus();
                return;
            }
            #endregion

            string sClassText = "";
            if (optCSharp.Checked == true)
            #region C# Class
            {

                sClassText += "public class " + sTableName + sTab + "{ " + sNewLine + sNewLine;

                //-- GENERATE THE START REGION PART 
                sClassText += sTab + sTab + "#region class scope variables" + sNewLine;
                sClassText += sTab + sTab + @"string lclStoredProcedure = """ + sStoredProcPrefix + sTableName + @""";" + sNewLine;
                sClassText += sTab + sTab + "string lclConnection = null;" + sNewLine;
                sClassText += sTab + sTab + "SqlConnection lcldbConn = new SqlConnection();" + sNewLine;
                sClassText += sTab + sTab + "public string DBConnection { get { return lclConnection; } set { lclConnection = value; } }" + sNewLine + sNewLine;

                sClassText += sTab + sTab + "#region local fields and properties" + sNewLine;




                #region GetDataTable of Fields In Table
                SqlConnectionStringBuilder SQLConnStrBldr = new SqlConnectionStringBuilder();

                SqlConnection SQLConn = new SqlConnection();

                string csSQL = "SELECT Ordinal_Position, column_name ,  CSharpDataType , CSharpPrivateVariablePrefix, IS_NULLABLE , CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, CSharpSQLReaderType, CSharpPrivateDefaultValue ";
                csSQL += "from [" + sDBName + "].[INFORMATION_SCHEMA].COLUMNS join [_InternalTools].[dbo].[DbVsCSharpTypes] ";
                csSQL += "on SQL2008DataType = Data_Type ";
                csSQL += "where TABLE_NAME='" + sTableName + "' ";
                csSQL += "order by Ordinal_Position";

                SQLConnStrBldr.DataSource = cboSQLServers.Text;
                if (optSQL.Checked == true)
                {
                    if (txtPassword.Text.Length == 0 | txtSQLUserName.Text.Length == 0)
                    {
                        MessageBox.Show("Enter a SQL User ID and it's password");
                        return;
                    }
                    else
                    {
                        SQLConnStrBldr.UserID = txtSQLUserName.Text;
                        SQLConnStrBldr.Password = txtPassword.Text;

                    }

                }
                SQLConnStrBldr.InitialCatalog = cboDatabases.Text;
                SQLConn.ConnectionString = SQLConnStrBldr.ConnectionString;
                SQLConn.Open();
                SqlDataAdapter adpTableOfColumns = new SqlDataAdapter(csSQL, SQLConnStrBldr.ConnectionString);
                DataTable dtColumns = new DataTable();
                adpTableOfColumns.Fill(dtColumns);
                #endregion

                foreach (DataRow dtRow in dtColumns.Rows)
                {

                    string sDataType = dtRow[2].ToString(); //sql reader field name - CSharpDataType
                    string svarPrivate = dtRow[3].ToString() + dtRow[1].ToString(); //sql reader field name - lowercase of first character of CSharpDataType then column_name
                    string sColName = dtRow[1].ToString(); //sql reader field name - column_name
                    string sDefaultValue = dtRow[9].ToString();
                    if (sDefaultValue.ToUpper() == "NULL")
                    {
                        sDefaultValue = "";
                    }
                    else
                    {
                        sDefaultValue = " = " + sDefaultValue;
                    }


                    //--GENERATE THE PRIVATE MEMEBER 
                    sClassText += sTab + sTab + "private " + sDataType + " " + svarPrivate + sDefaultValue + ";" + sNewLine;

                    //-- GENERATE THE PUBLIC MEMBER 
                    sClassText += sTab + sTab + "public " + sDataType + " " + sColName + "{";
                    sClassText += sTab + sTab + sTab + "get { return " + svarPrivate + "; } ";
                    sClassText += sTab + sTab + sTab + "set { " + svarPrivate + " = value ; }";
                    sClassText += sTab + sTab + "} " + sNewLine + sNewLine;   //eof prop ' + @ColName + CHAR(13) + CHAR(13)

                }

                //-- GENERATE THE END REGION PART 
                sClassText += sTab + sTab + "#endregion " + sNewLine;
                sClassText += sTab + sTab + "#endregion " + sNewLine;

                DataTable dtPrimaryKeys = new DataTable();
                dtPrimaryKeys = GetPrimaryKeysWithDataTypes(sDBName, sTableName);

                sClassText += AddCRUDToCSharpClass("CREATE", dtColumns, dtPrimaryKeys);
                sClassText += AddCRUDToCSharpClass("READALL", dtColumns, null);
                sClassText += AddCRUDToCSharpClass("READNUN", dtColumns, null);
                sClassText += AddCRUDToCSharpClass("UPDATE", dtColumns, null);
                sClassText += AddCRUDToCSharpClass("DELETE", dtColumns, null);

                sClassText += "}";

            }
            #endregion
            else
            #region create VB class
            {
                sClassText += "Imports System.Data.SqlClient" + sNewLine + sNewLine;
                sClassText += "Public Class " + sTableName + sTab + sNewLine + sNewLine;
                //-- GENERATE THE START REGION PART 
                sClassText += sTab + sTab + @"#Region ""class scope variables""" + sNewLine;
                sClassText += sTab + sTab + @"Private Dim lclStoredProcedure As string = """ + sStoredProcPrefix + sTableName + @"""" + sNewLine;
                sClassText += sTab + sTab + @"Private Dim lclConnection As string = """"" + sNewLine;
                sClassText += sTab + sTab + "Private lcldbConn As SqlConnection = New SqlConnection()" + sNewLine;
                sClassText += sTab + sTab + "Public Property DBConnection() As String " + sNewLine + "Get " + sNewLine + "Return lclConnection" + sNewLine + "End Get" + sNewLine;
                sClassText += sTab + sTab + "Set(ByVal value As String)" + sNewLine + "lclConnection = value" + sNewLine + "End Set" + sNewLine;
                sClassText += sTab + sTab + "End Property" + sNewLine + sNewLine;
                sClassText += sTab + sTab + @"#Region ""local fields and properties""" + sNewLine;
                #region GetDataTable of Fields In Table
                SqlConnectionStringBuilder SQLConnStrBldr = new SqlConnectionStringBuilder();
                SqlConnection SQLConn = new SqlConnection();

                string csSQL = "SELECT Ordinal_Position, column_name ,  CSharpDataType , CSharpPrivateVariablePrefix, IS_NULLABLE , CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE  ";
                csSQL += "from [" + sDBName + "].[INFORMATION_SCHEMA].COLUMNS join [_InternalTools].[dbo].[DbVsCSharpTypes] ";
                csSQL += "on SQL2008DataType = Data_Type ";
                csSQL += "where TABLE_NAME='" + sTableName + "' ";
                csSQL += "order by Ordinal_Position";

                SQLConnStrBldr.DataSource = cboSQLServers.Text;

                SQLConnStrBldr.DataSource = cboSQLServers.Text;
                if (optSQL.Checked == true)
                {
                    if (txtPassword.Text.Length == 0 | txtSQLUserName.Text.Length == 0)
                    {
                        MessageBox.Show("Enter a SQL User ID and it's password");
                        return;
                    }
                    else
                    {
                        SQLConnStrBldr.UserID = txtSQLUserName.Text;
                        SQLConnStrBldr.Password = txtPassword.Text;

                    }

                }


                SQLConnStrBldr.InitialCatalog = cboDatabases.Text;
                //SQLConn.ConnectionString = SQLConnStrBldr.ConnectionString;
                SQLConn.Open();
                SqlDataAdapter adpTableOfColumns = new SqlDataAdapter(csSQL, SQLConnStrBldr.ConnectionString);
                DataTable dtColumns = new DataTable();
                adpTableOfColumns.Fill(dtColumns);
                #endregion

               foreach (DataRow dtRow in dtColumns.Rows)
                {

                    string sDataType = dtRow[2].ToString(); //todo sql reader field name - CSharpDataType
                    string svarPrivate = dtRow[3].ToString() + dtRow[1].ToString(); //todo sql reader field name - lowercase of first character of CSharpDataType then column_name
                    string sColName = dtRow[1].ToString(); //todo sql reader field name - column_name

                    //--GENERATE THE PRIVATE MEMEBER 
                    sClassText += sTab + sTab + "Private " + svarPrivate + " As " + sDataType + sNewLine;

                    //-- GENERATE THE PUBLIC MEMBER 
                    sClassText += sTab + sTab + "Public Property " + sColName + "() As " + sDataType + " " + sNewLine;
                    sClassText += sTab + sTab + sTab + "Get " + sNewLine;
                    sClassText += sTab + sTab + sTab + "Return " + svarPrivate + " " + sNewLine;
                    sClassText += sTab + sTab + sTab + "End Get" + sNewLine;
                    sClassText += sTab + sTab + sTab + "Set(ByVal value As " + sDataType + ")" + sNewLine;
                    sClassText += sTab + sTab + sTab + svarPrivate + " = value" + sNewLine;
                    sClassText += sTab + sTab + sTab + "End Set " + sNewLine;   //eof prop ' + @ColName + CHAR(13) + CHAR(13)
                    sClassText += sTab + sTab + sTab + "End Property " + sNewLine + sNewLine;   //eof prop ' + @ColName + CHAR(13) + CHAR(13)
                }

                                //-- GENERATE THE END REGION PART 
                sClassText += sTab + sTab + "#End Region " + sNewLine;
                sClassText += sTab + sTab + "#End Region " + sNewLine;

                sClassText += AddCRUDToVBClass("CREATE", dtColumns);
                //sClassText += AddCRUDToClass("READALL", dtColumns);
                sClassText += AddCRUDToVBClass("READUNIQUE", dtColumns);
                sClassText += AddCRUDToVBClass("UPDATE", dtColumns);
                sClassText += AddCRUDToVBClass("DELETE", dtColumns);


                sClassText += "End Class";
            }
            #endregion


            txtClassCode.Text = sClassText;


        }
                
        private void frmMain_Load(object sender, EventArgs e)
        {
            ////todo get list of available sql servers, so one can be selected then 
            ////allow the user to select a database and a table
            //sSQLVersion = new ArrayList();
            ////DataTable ctblSQLSources = SqlClientFactory.Instance.CreateDataSourceEnumerator().GetDataSources();
            //SqlDataSourceEnumerator instance =
            //SqlDataSourceEnumerator.Instance;
            //System.Data.DataTable ctblSQLSources = instance.GetDataSources();
            //foreach (DataRow DRow in ctblSQLSources.Rows)
            //{
            //    string sSQLServerInstance = DRow[0].ToString() +"\\"+ DRow[1].ToString();
            //    cboSQLServers.Items.Add(sSQLServerInstance);
            //    sSQLVersion.Add(sSQLServerInstance.Replace("\\",@"\") + "~" + DRow[3].ToString());
            //}

            SqlDataSourceEnumerator instance = SqlDataSourceEnumerator.Instance;
            DataTable table = instance.GetDataSources();
            string ServerName = Environment.MachineName;
            foreach (DataRow row in table.Rows)
            {
                //Console.WriteLine(ServerName + "\\" + row["InstanceName"].ToString());
                string sSQLServerInstance = ServerName + "\\" + row["InstanceName"].ToString();
                cboSQLServers.Items.Add(sSQLServerInstance);
            }
            //threadSplash.Abort();

        }

        private void cboSQLServers_Leave(object sender, EventArgs e)
        {
            if (cboSQLServers.Text.Length > 0)
            {
                cboSQLServers_SelectedIndexChanged(this, null);
            }
        }

        private void cboSQLServers_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                cboDatabases.Items.Clear();

                SqlConnectionStringBuilder SQLConnStrBldr = new SqlConnectionStringBuilder();
                SqlConnection SQLConn = new SqlConnection();

                if (cboSQLServers.Text.Length > 0)
                {
                    SQLConnStrBldr.DataSource = cboSQLServers.Text;
                    SQLConnStrBldr.IntegratedSecurity = optWindows.Checked;

                    if (optSQL.Checked == true)
                    {
                        if (txtPassword.Text.Length == 0 | txtSQLUserName.Text.Length == 0)
                        {
                            MessageBox.Show("Enter a SQL User ID and it's password");
                            return;
                        }
                        else
                        {
                            SQLConnStrBldr.UserID = txtSQLUserName.Text;
                            SQLConnStrBldr.Password = txtPassword.Text;

                        }

                    }

                    SQLConn.ConnectionString = SQLConnStrBldr.ConnectionString;
                    SQLConn.Open();
                    DataTable tblDatabases = SQLConn.GetSchema("Databases");


                    foreach (DataRow dtRow in tblDatabases.Rows)
                    {
                        cboDatabases.Items.Add(dtRow["Database_Name"]);
                    }

                    //foreach (string sSearchSQLVersion in sSQLVersion)
                    //{
                    //    string sTestString = sSearchSQLVersion.Substring(0, sSearchSQLVersion.IndexOf("~"));
                    //    sSelectedSQLVersion = sSearchSQLVersion.Substring(sSearchSQLVersion.IndexOf("~") + 1);
                    //    if (sTestString == cboSQLServers.Text)
                    //    {
                    //        break;

                    //    }
                    //}


                }
            }
            catch (Exception ce)
            {
                MessageBox.Show(ce.Message, "Error Loading SQL Databases", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }

           

        }

        private void cboDatabases_SelectedIndexChanged(object sender, EventArgs e)
        {
            //get tables in the selected sql server instance and database
            //select * from INFORMATION_SCHEMA.tables 
            cboTables.Items.Clear();

            SqlConnectionStringBuilder SQLConnStrBldr = new SqlConnectionStringBuilder();
            SqlConnection SQLConn = new SqlConnection();

            if (cboSQLServers.Text.Length > 0)
            {
                SQLConnStrBldr.DataSource = cboSQLServers.Text;
                SQLConnStrBldr.IntegratedSecurity = optWindows.Checked;
                SQLConnStrBldr.InitialCatalog = cboDatabases.Text;
                
            if (optSQL.Checked == true)
            {
                if( txtPassword.Text.Length == 0 | txtSQLUserName.Text.Length == 0 )
                {
                    MessageBox.Show("Enter a SQL User ID and it's password");
                    return;
                }
                else
                {
                    SQLConnStrBldr.UserID = txtSQLUserName.Text;
                    SQLConnStrBldr.Password = txtPassword.Text;

                }

            }

                SQLConn.ConnectionString = SQLConnStrBldr.ConnectionString;
                SQLConn.Open();
                SqlDataAdapter adpTables = new SqlDataAdapter("select * from INFORMATION_SCHEMA.tables Order By Table_Name", SQLConn);
                DataTable dtblTables = new DataTable();
                adpTables.Fill(dtblTables);

                foreach(DataRow dtRow in dtblTables.Rows)
                {
                    cboTables.Items.Add(dtRow["Table_Name"]);
                }

            }
        }

        private string AddCRUDToCSharpClass(string sTODO, DataTable dtColumns, DataTable dtPrimaryKeysWithDataType)
        {
            // find way to get primary key fields, find way to get the sTODO method to set those
            // those key fields with in the class
            string stempClassString = "";
            string sColNamePrefix = "";

            if (sTODO == "READALL" | sTODO == "READNUN")
            {
                stempClassString += "public DataTable " + sTODO + "()" + sNewLine;
            }
            else
            {
                stempClassString += "public void " + sTODO + "()" + sNewLine;
            }
            stempClassString += "{" + sNewLine;

            stempClassString += "SqlCommand lclSQLCOM = new SqlCommand();" + sNewLine;
            stempClassString += "lcldbConn.ConnectionString = lclConnection;" + sNewLine;
            stempClassString += "lclSQLCOM.Connection = lcldbConn;" + sNewLine;
            stempClassString += "lclSQLCOM.CommandType = System.Data.CommandType.StoredProcedure;" + sNewLine;
            stempClassString += "lclSQLCOM.CommandText = lclStoredProcedure;" + sNewLine;

            foreach (DataRow dtRow in dtColumns.Rows)
            {
                string sColName = dtRow[1].ToString(); //todo sql reader field name - column_name
                stempClassString += @"lclSQLCOM.Parameters.AddWithValue(""@" + sColName + @""", " + sColName + ");" + sNewLine;
                sColNamePrefix = sColName.Substring(0,3);
            }

            stempClassString += @"lclSQLCOM.Parameters.AddWithValue(""@" + txtVerbWord.Text.Trim() + @""", """ + sTODO + @""");" + sNewLine;
            stempClassString += "lcldbConn.Open();" + sNewLine;
            if (sTODO == "DELETE" | sTODO == "UPDATE")
            {
                stempClassString += "lclSQLCOM.ExecuteNonQuery();" + sNewLine;
                stempClassString += "lclSQLCOM.Cancel();" + sNewLine;
                stempClassString += "lcldbConn.Close();" + sNewLine;
                stempClassString += "}" + sNewLine;
            }
            else if (sTODO == "CREATE")
            {
                stempClassString += "SqlDataReader SQLReader = lclSQLCOM.ExecuteReader();" + sNewLine;

                stempClassString += "while (SQLReader.Read())" + sNewLine;
                stempClassString += "{" + sNewLine;
                //loop through primary keys to set local fields IDs within the create method being generated
                foreach (DataRow dtRow in dtPrimaryKeysWithDataType.Rows)
                {
                    string sDataType = dtRow[2].ToString(); //sql reader field name - CSharpDataType
                    string svarPrivate = dtRow[3].ToString() + dtRow[0].ToString(); //sql reader field name - lowercase of first character of CSharpDataType then column_name
                    string sColName = dtRow[0].ToString(); //sql reader field name - column_name
                    string sSQLReader = dtRow[9].ToString();

                    stempClassString += svarPrivate + " = SQLReader.Get" + sSQLReader + @"(SQLReader.GetOrdinal(""" + sColName + @"""));" + sNewLine;
                }
                //stempClassString += @"//TODO [USE LOCAL FIELD ID HERE] = SQLReader.GetSqlGuid(SQLReader.GetOrdinal(""" + sColNamePrefix + @"[USE LOCAL FIELD ID HERE]"")).ToString();" + sNewLine;
                stempClassString += "}" + sNewLine;
                stempClassString += "lclSQLCOM.Cancel();" + sNewLine;
                stempClassString += "lcldbConn.Close();" + sNewLine;
                stempClassString += "}" + sNewLine;
            }
            //else if (sTODO == "READNUN")
            //{

            //    stempClassString += "SqlDataReader SQLReader = lclSQLCOM.ExecuteReader();" + sNewLine;

            //    stempClassString += "while (SQLReader.Read())" + sNewLine;
            //    stempClassString += "{" + sNewLine;

            //    stempClassString += "//TODO need to get class generator to go through the values in returned record and set them to the local class fields" + sNewLine;

            //    stempClassString += "}" + sNewLine;
            //    stempClassString += "lclSQLCOM.Cancel();" + sNewLine;
            //    stempClassString += "lcldbConn.Close();" + sNewLine;
            //    stempClassString += "}" + sNewLine;

            //}
            else if (sTODO == "READNUN" | sTODO == "READALL")
            {

                stempClassString += "SqlDataAdapter apdRetrievedData = new SqlDataAdapter(lclSQLCOM);" + sNewLine;
                stempClassString += "DataTable dtColumns = new DataTable();" + sNewLine;
                stempClassString += "apdRetrievedData.Fill(dtColumns);" + sNewLine;
                stempClassString += "lclSQLCOM.Cancel();" + sNewLine;
                stempClassString += "lcldbConn.Close();" + sNewLine;
                stempClassString += "return dtColumns;" + sNewLine;

                //stempClassString += @"//TODO [USE LOCAL FIELD ID HERE] = SQLReader.GetSqlGuid(SQLReader.GetOrdinal(""" + sColNamePrefix + @"[USE LOCAL FIELD ID HERE]"")).ToString();" + sNewLine;
                stempClassString += "}" + sNewLine;
            }


            return stempClassString;
        }

        private string AddCRUDToVBClass(string sTODO, DataTable dtColumns)
        {
            // find way to get primary key fields, find way to get the sTODO method to set those
            // those key fields with in the class
            string stempClassString = "";
            string sColNamePrefix = "";
            if (sTODO == "READALL")
            {
                stempClassString += "Public Function " + sTODO + "() As DataTable" + sNewLine;
            }
            else
            {
                stempClassString += "Public Sub " + sTODO + "()" + sNewLine;
            }

            stempClassString += "Dim lclSQLCOM As SqlCommand = New SqlCommand()" + sNewLine;
            stempClassString += "lcldbConn.ConnectionString = lclConnection" + sNewLine;
            stempClassString += "lclSQLCOM.Connection = lcldbConn" + sNewLine;
            stempClassString += "lclSQLCOM.CommandType = System.Data.CommandType.StoredProcedure" + sNewLine;
            stempClassString += "lclSQLCOM.CommandText = lclStoredProcedure" + sNewLine;

            foreach (DataRow dtRow in dtColumns.Rows)
            {
                string sColName = dtRow[1].ToString(); //todo sql reader field name - column_name
                stempClassString += @"lclSQLCOM.Parameters.AddWithValue(""@" + sColName + @""", " + sColName + ")" + sNewLine;
                sColNamePrefix = sColName.Substring(0, 3);
            }

            stempClassString += @"lclSQLCOM.Parameters.AddWithValue(""@" + txtVerbWord.Text.Trim() + @""", """ + sTODO + @""")" + sNewLine;
            stempClassString += "lcldbConn.Open()" + sNewLine;
            if (sTODO == "DELETE" | sTODO == "UPDATE")
            {
                stempClassString += "lclSQLCOM.ExecuteNonQuery()" + sNewLine;
            }
            else if (sTODO == "CREATE")
            {
                stempClassString += "Dim SQLReader As SqlDataReader = lclSQLCOM.ExecuteReader()" + sNewLine;

                stempClassString += "While (SQLReader.Read())" + sNewLine;
                //TODO loop through primary keys to set local fields IDs within the create method being generated
                stempClassString += @"'TODO [USE LOCAL FIELD ID HERE] = SQLReader.GetSqlGuid(SQLReader.GetOrdinal(""" + sColNamePrefix + @"[USE LOCAL FIELD ID HERE]"")).ToString();" + sNewLine;
                stempClassString += "End While" + sNewLine;
            }
            else if (sTODO == "READUNIQUE")
            {

                stempClassString += "Dim SQLReader As SqlDataReader = lclSQLCOM.ExecuteReader()" + sNewLine;

                stempClassString += "While (SQLReader.Read())" + sNewLine;

                stempClassString += "'TODO need to get class generator to go through the values in returned record and set them to the local class fields" + sNewLine;

                stempClassString += "End While" + sNewLine;


            }

            stempClassString += "lclSQLCOM.Cancel()" + sNewLine;

            stempClassString += "End Sub" + sNewLine;
            return stempClassString;
        }

        private void btnCopyToClipboardCSharpClass_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(txtClassCode.Text, true);
        }

        private void btnCopyToClipboardStoredProc_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(txtStoredProc.Text, true);
        }

        private void btnCreateStoredProc_Click(object sender, EventArgs e)
        {
            string sDBName = cboDatabases.Text.Trim();
            string sTableName = cboTables.Text.Trim();
            string sStoredProcPrefix = txtStoredProcPrefix.Text.Trim();
            string sVerbWord = txtVerbWord.Text.Trim();
            #region validate inputs
            if (sDBName.Length == 0)
            {
                MessageBox.Show("Select a database name.", "Missing Database Name", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cboDatabases.Focus();
                return;
            }
            if (sTableName.Length == 0)
            {
                MessageBox.Show("Select a table name.", "Missing Table Name", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cboTables.Focus();
                return;

            }
            if (sStoredProcPrefix.Length == 0)
            {
                MessageBox.Show("Enter a few characters for a Stored Proc Prefix.", "Missing Stored Proc Prefix", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtStoredProcPrefix.Focus();
                return;
            }
            if (sVerbWord.Length == 0)
            {
                MessageBox.Show("Enter a few characters for a Stored Proc Verb Word.", "Missing Stored Proc Verb Word", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtVerbWord.Focus();
                return;
            }
            #endregion

            #region GetDataTable Of Primary Indexes

            SqlConnectionStringBuilder SQLConnStrBldr = new SqlConnectionStringBuilder();
            SqlConnection SQLConn = new SqlConnection();

            SQLConnStrBldr.DataSource = cboSQLServers.Text;
            SQLConnStrBldr.IntegratedSecurity = optWindows.Checked;
            SQLConnStrBldr.InitialCatalog = cboDatabases.Text;

            if (optSQL.Checked == true)
            {
                if (txtPassword.Text.Length == 0 | txtSQLUserName.Text.Length == 0)
                {
                    MessageBox.Show("Enter a SQL User ID and it's password");
                    return;
                }
                else
                {
                    SQLConnStrBldr.UserID = txtSQLUserName.Text;
                    SQLConnStrBldr.Password = txtPassword.Text;

                }

            }
            SQLConn.ConnectionString = SQLConnStrBldr.ConnectionString;
            SQLConn.Open();
            DataTable dtPrimaryKeys = new DataTable();
            dtPrimaryKeys = GetPrimaryKeys(sDBName, sTableName);
            #endregion

            #region GetDataTable of Fields In Table

            string csSQL = "SELECT Ordinal_Position, column_name ,  CSharpDataType , CSharpPrivateVariablePrefix, IS_NULLABLE , CHARACTER_MAXIMUM_LENGTH, Data_Type, NUMERIC_PRECISION, NUMERIC_SCALE  ";
            csSQL += "from [" + sDBName + "].[INFORMATION_SCHEMA].COLUMNS join [_InternalTools].[dbo].[DbVsCSharpTypes] ";
            csSQL += "on SQL2008DataType = Data_Type ";
            csSQL += "where TABLE_NAME='" + sTableName + "' ";
            csSQL += "order by Ordinal_Position";

            SqlDataAdapter adpTableOfColumns = new SqlDataAdapter(csSQL, SQLConnStrBldr.ConnectionString);
            DataTable dtColumns = new DataTable();
            adpTableOfColumns.Fill(dtColumns);
            #endregion

            string sStoreProcText = "";
            #region Build Use statement & rename procedure
            sStoreProcText += "USE [" + sDBName + "]" + sNewLine;
            sStoreProcText += "GO" + sNewLine;
            sStoreProcText += "IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[" + sStoredProcPrefix + sTableName + "]') AND type in (N'P', N'PC'))" + sNewLine;
            sStoreProcText += "execute sp_rename '" + sStoredProcPrefix + sTableName + "','" + sStoredProcPrefix + sTableName + "_" + DateTime.Now.ToLocalTime().ToString("yyyyMMdd") + "'" + sNewLine;
            sStoreProcText += "GO" + sNewLine;
            sStoreProcText += sNewLine;
            #endregion

            #region Build Procedure for class
            sStoreProcText += "USE [" + sDBName + "]" + sNewLine;
            sStoreProcText += "GO" + sNewLine;
            sStoreProcText += "Create Procedure [dbo].[" + sStoredProcPrefix + sTableName + "]" + sNewLine;
            sStoreProcText += "(" + sNewLine;
            string sInsertDestination = "INSERT INTO [dbo].[" + sTableName +"] (";
            string sInsertSource = "SELECT ";
            string sUpdateSet = "SET ";
            #region Build Parameters and bits and pieces of crud statements
            foreach (DataRow dtRow in dtColumns.Rows)
            {
                string sCSharpDataType = dtRow[2].ToString(); //sql reader field name - CSharpDataType
                string sSQL2008DataType = dtRow[6].ToString();
                string sColumnLength = dtRow[5].ToString();
                string sNumeric_Precision = dtRow[7].ToString();
                string sNumeric_Scale = dtRow[8].ToString();
                string sColName = dtRow[1].ToString(); //sql reader field name - column_name

                #region Build Parameter Section
                sStoreProcText += sTab + "@" + sColName + " as " + sSQL2008DataType;
                if ((sColumnLength.Length > 0))
                {
                    if (sColumnLength == "-1")
                    {
                        sStoreProcText += "(MAX),";
                    }
                    else
                    {
                        sStoreProcText += "(" + sColumnLength + "),";
                    }
                }
                else if (sNumeric_Precision.Length > 0 
                         & !(sSQL2008DataType.ToUpper().IndexOf("INT") > -1))

                {
                    sStoreProcText += "(" + sNumeric_Precision;
                    if (sNumeric_Scale.Length > 0)
                    {
                        sStoreProcText += "," + sNumeric_Scale + "),";
                    }
                    else
                    {
                        sStoreProcText += "),";
                    }
                }
                else
                {
                    sStoreProcText += ",";
                }
                sStoreProcText += sNewLine;
                #endregion

                #region Build Insert Destination Fields
                sInsertDestination += "[" + sColName + "], ";

                #endregion

                #region Build Insert Source Fields
                sInsertSource += "@" + sColName + ", ";

                #endregion

                #region Build Update Set Fields
                sUpdateSet += "[" + sColName + "] = @" + sColName + ", ";

                #endregion

            }
            sInsertDestination = sInsertDestination.Substring(0, sInsertDestination.Length - 2);
            sInsertDestination += ")" + sNewLine;
            sInsertSource = sInsertSource.Substring(0, sInsertSource.Length - 2);
            sUpdateSet = sUpdateSet.Substring(0, sUpdateSet.Length - 2);
            #endregion

            #region Build Where clauses based on primary indexes
            string sWhere = "Where ";
            foreach (DataRow dtRow in dtPrimaryKeys.Rows)
            {
                if (sWhere.Length > 6)
                {
                    sWhere += " AND ";
                }
                sWhere += "@" + dtRow[0].ToString() + " = [" + dtRow[0].ToString() + "]";

            }
            #endregion

            #region Build Procedure Body
            sStoreProcText += sTab + "@" + sVerbWord + " nvarchar(10)" + sNewLine;
            sStoreProcText += ")" + sNewLine;
            sStoreProcText += "AS" + sNewLine;
            sStoreProcText += "Begin" + sNewLine;
            //insert new record
            sStoreProcText += sTab + "IF @" + sVerbWord + " = 'CREATE'" + sNewLine;
            sStoreProcText += sTab + "Begin" + sNewLine;
            sStoreProcText += sTab + sTab + sInsertDestination;
            sStoreProcText += sTab + sTab + sInsertSource + sNewLine;
            sStoreProcText += sTab + "End" + sNewLine;
            //update record
            sStoreProcText += sTab + "IF @" + sVerbWord + " = 'UPDATE'" + sNewLine;
            sStoreProcText += sTab + "Begin" + sNewLine;
            sStoreProcText += sTab + sTab + "UPDATE [dbo].[" + sTableName + "]" + sNewLine;
            sStoreProcText += sTab + sTab + sUpdateSet + sNewLine;
            sStoreProcText += sTab + sTab + sWhere + sNewLine;
            sStoreProcText += sTab + "End" + sNewLine;
            //delete a record
            sStoreProcText += sTab + "IF @" + sVerbWord + " = 'DELETE'" + sNewLine;
            sStoreProcText += sTab + "Begin" + sNewLine;
            sStoreProcText += sTab + sTab + "DELETE [dbo].[" + sTableName + "]" + sNewLine;
            sStoreProcText += sTab + sTab + sWhere + sNewLine;
            sStoreProcText += sTab + "End" + sNewLine;
            //read all records
            sStoreProcText += sTab + "IF @" + sVerbWord + " = 'READALL'" + sNewLine;
            sStoreProcText += sTab + "Begin" + sNewLine;
            sStoreProcText += sTab + sTab + "Select * from [dbo].[" + sTableName + "]" + sNewLine;
            sStoreProcText += sTab + "End" + sNewLine;
            //read unique record
            sStoreProcText += sTab + "IF @" + sVerbWord + " = 'READNUN'" + sNewLine;
            sStoreProcText += sTab + "Begin" + sNewLine;
            sStoreProcText += sTab + sTab + "Select * from [dbo].[" + sTableName + "]" + sNewLine;
            sStoreProcText += sTab + sTab + sWhere + sNewLine;
            sStoreProcText += sTab + "End" + sNewLine;
            sStoreProcText += "End" + sNewLine;
            #endregion
            #endregion

            txtStoredProc.Text = sStoreProcText;
        }

        private DataTable GetPrimaryKeys(string sDBName, string sTableName)
        {
            SqlConnectionStringBuilder SQLConnStrBldr = new SqlConnectionStringBuilder();
            SqlConnection SQLConn = new SqlConnection();

            string csSQL = "Select [COLUMN_NAME], ORDINAL_POSITION ";
            csSQL += "from [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS] ";
            csSQL += "join [" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE] ";
            csSQL += "on [" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE].CONSTRAINT_NAME =  [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].CONSTRAINT_NAME ";
            csSQL += "where [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].TABLE_NAME = '" + sTableName + "' AND CONSTRAINT_TYPE = 'PRIMARY KEY' ";
            csSQL += "ORDER BY ORDINAL_POSITION";

            SQLConnStrBldr.DataSource = cboSQLServers.Text;
            SQLConnStrBldr.IntegratedSecurity = optWindows.Checked;

            if (optSQL.Checked == true)
            {
                if (txtPassword.Text.Length == 0 | txtSQLUserName.Text.Length == 0)
                {
                    MessageBox.Show("Enter a SQL User ID and it's password");
                    return null;
                }
                else
                {
                    SQLConnStrBldr.UserID = txtSQLUserName.Text;
                    SQLConnStrBldr.Password = txtPassword.Text;

                }

            }
            SQLConnStrBldr.InitialCatalog = cboDatabases.Text;
            SQLConn.ConnectionString = SQLConnStrBldr.ConnectionString;
            SQLConn.Open();
            SqlDataAdapter adpTableOfKeys = new SqlDataAdapter(csSQL, SQLConnStrBldr.ConnectionString);
            DataTable dtColumns = new DataTable();
            adpTableOfKeys.Fill(dtColumns);
            return dtColumns;
        }

        private DataTable GetPrimaryKeysWithDataTypes(string sDBName, string sTableName)
        {
            SqlConnectionStringBuilder SQLConnStrBldr = new SqlConnectionStringBuilder();
            SqlConnection SQLConn = new SqlConnection();

            //string csSQL = "Select [COLUMN_NAME], ORDINAL_POSITION,  CSharpDataType , CSharpPrivateVariablePrefix, IS_NULLABLE , CHARACTER_MAXIMUM_LENGTH, Data_Type, NUMERIC_PRECISION, NUMERIC_SCALE ";
            //csSQL += "from [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS] ";
            //csSQL += "join [" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE] ";
            //csSQL += "on [" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE].CONSTRAINT_NAME =  [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].CONSTRAINT_NAME ";
            //csSQL += "join [" + sDBName + "].[INFORMATION_SCHEMA].COLUMNS join [_InternalTools].[dbo].[DbVsCSharpTypes] ";
            //csSQL += "on SQL2008DataType = Data_Type "; 
            //csSQL += "where [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].TABLE_NAME = '" + sTableName + "' AND CONSTRAINT_TYPE = 'PRIMARY KEY' ";
            //csSQL += "ORDER BY ORDINAL_POSITION";
            string csSQL = "";
            if (sSelectedSQLVersion.Substring(0, sSelectedSQLVersion.IndexOf(".")) == "10" | sSelectedSQLVersion.Substring(0, sSelectedSQLVersion.IndexOf(".")) == "11")
            {
            //what's below here works fine in 2008 express
                csSQL = "SELECT COLS.[COLUMN_NAME], ORDINAL_POSITION,CSharpDataType , CSharpPrivateVariablePrefix, ";
                csSQL += "IS_NULLABLE , CHARACTER_MAXIMUM_LENGTH, Data_Type, NUMERIC_PRECISION, NUMERIC_SCALE, CSharpSQLReaderType ";
                csSQL += "FROM [" + sDBName + "].[INFORMATION_SCHEMA].COLUMNS ";
                csSQL += "join (Select [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].[TABLE_NAME], [COLUMN_NAME] ";
                csSQL += "from [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS] ";
                csSQL += "join [" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE] ";
                csSQL += "on [" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE].CONSTRAINT_NAME =  [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].CONSTRAINT_NAME ";
                csSQL += "where [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].TABLE_NAME = '" + sTableName + "' AND CONSTRAINT_TYPE = 'PRIMARY KEY' ";
                csSQL += ") COLS ON COLS.TABLE_NAME = COLUMNS.TABLE_NAME AND COLS.COLUMN_NAME = COLUMNS.COLUMN_NAME ";
                csSQL += "join [_InternalTools].[dbo].[DbVsCSharpTypes] ";
                csSQL += "on SQL2008DataType = Data_Type";
            }
            else if (sSelectedSQLVersion.Substring(0, sSelectedSQLVersion.IndexOf(".")) == "9")
            {
            //what's below here works fine in 2005 
                csSQL = "SELECT COLS.[COLUMN_NAME], ORDINAL_POSITION,CSharpDataType , CSharpPrivateVariablePrefix, ";
                csSQL += "IS_NULLABLE , CHARACTER_MAXIMUM_LENGTH, Data_Type, NUMERIC_PRECISION, NUMERIC_SCALE, CSharpSQLReaderType ";
                csSQL += "FROM [" + sDBName + "].[INFORMATION_SCHEMA].COLUMNS ACOL ";
                csSQL += "join (Select [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].[TABLE_NAME], ";
                csSQL += "[" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE].[COLUMN_NAME] ";
                csSQL += "from [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS] ";
                csSQL += "join [" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE] ";
                csSQL += "on [" + sDBName + "].[INFORMATION_SCHEMA].[KEY_COLUMN_USAGE].CONSTRAINT_NAME = ";
                csSQL += "[" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].CONSTRAINT_NAME ";
                csSQL += "where [" + sDBName + "].[INFORMATION_SCHEMA].[TABLE_CONSTRAINTS].TABLE_NAME = '" + sTableName + "' ";
                csSQL += "AND CONSTRAINT_TYPE = 'PRIMARY KEY' ) COLS ";
                csSQL += "ON COLS.TABLE_NAME = ACOL.TABLE_NAME AND COLS.COLUMN_NAME = ACOL.COLUMN_NAME ";
                csSQL += "join [_InternalTools].[dbo].[DbVsCSharpTypes] ";
                csSQL += "on SQL2008DataType = Data_Type";
            }
            SQLConnStrBldr.DataSource = cboSQLServers.Text;
            SQLConnStrBldr.IntegratedSecurity = optWindows.Checked;

            if (optSQL.Checked == true)
            {
                if (txtPassword.Text.Length == 0 | txtSQLUserName.Text.Length == 0)
                {
                    MessageBox.Show("Enter a SQL User ID and it's password");
                    return null;
                }
                else
                {
                    SQLConnStrBldr.UserID = txtSQLUserName.Text;
                    SQLConnStrBldr.Password = txtPassword.Text;

                }

            }
            SQLConnStrBldr.InitialCatalog = cboDatabases.Text;
            SQLConn.ConnectionString = SQLConnStrBldr.ConnectionString;
            SQLConn.Open();
            SqlDataAdapter adpTableOfKeys = new SqlDataAdapter(csSQL, SQLConnStrBldr.ConnectionString);
            DataTable dtColumns = new DataTable();
            adpTableOfKeys.Fill(dtColumns);
            return dtColumns;
        }

        private void cboTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder SQLConnStrBldr = new SqlConnectionStringBuilder();
            SqlConnection SQLConn = new SqlConnection();

            if (cboSQLServers.Text.Length > 0)
            {
                SQLConnStrBldr.DataSource = cboSQLServers.Text;
                SQLConnStrBldr.IntegratedSecurity = optWindows.Checked;
                SQLConnStrBldr.InitialCatalog = cboDatabases.Text;

                if (optSQL.Checked == true)
                {
                    if (txtPassword.Text.Length == 0 | txtSQLUserName.Text.Length == 0)
                    {
                        MessageBox.Show("Enter a SQL User ID and it's password");
                        return;
                    }
                    else
                    {
                        SQLConnStrBldr.UserID = txtSQLUserName.Text;
                        SQLConnStrBldr.Password = txtPassword.Text;

                    }

                }
                txtSQLString.Text = SQLConnStrBldr.ConnectionString;
            }
        }

        private void optSQL_CheckedChanged(object sender, EventArgs e)
        {

            txtSQLUserName.Visible = optSQL.Checked;

            txtPassword.Visible = optSQL.Checked;
        }

        private void optWindows_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnCopySQLStringToClipboard_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(txtSQLString.Text, true);
        }

        private void cboSQLServers_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsControl(e.KeyChar))
            {
                cboSQLServers_SelectedIndexChanged(this, null);



            }
        }



//        private         var registryViewArray ()
//        {
//            = new[] { RegistryView.Registry32, RegistryView.Registry64 };

//foreach (var registryView in registryViewArray)
//{
//    using (var hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, registryView))
//    using (var key = hklm.OpenSubKey(@"SOFTWARE\Microsoft\Microsoft SQL Server"))
//    {
//        var instances = (string[]) key?.GetValue("InstalledInstances");
//        if (instances != null)
//        {
//            foreach (var element in instances)
//            {
//                if (element == "MSSQLSERVER")
//                    Console.WriteLine(System.Environment.MachineName);
//                else
//                    Console.WriteLine(System.Environment.MachineName + @"\" + element);

//            }
//        }
//    }
//}
//        }
    }
}


//Using EnumAvailableSqlServers Class
 
//First of all, you need to add a reference to the Microsoft.SqlServer.smo.dll file to your project which is available in NuGet Package Manager.
//private void GetDataSources()  
//{  
//    DataTable table = SmoApplication.EnumAvailableSqlServers(true);  
//    string ServerName = Environment.MachineName;  
//    foreach (DataRow row in table.Rows)  
//    {  
//        Console.WriteLine(ServerName + "\\" + row["InstanceName"].ToString());  
//    }  
//} 
//EnumAvailableSqlServers and SqlDataSourceEnumerator will only find named instances if the SQL Server Browser services are running. If you want to get the SQL Server instance name on the current computer, you can read the information from the registry.
//private void GetDataSources2()  
//{  
//    string ServerName = Environment.MachineName;  
//    RegistryView registryView = Environment.Is64BitOperatingSystem ? RegistryView.Registry64 : RegistryView.Registry32;  
//    using (RegistryKey hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, registryView))  
//    {  
//        RegistryKey instanceKey = hklm.OpenSubKey(@"SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL", false);  
//        if (instanceKey != null)  
//        {  
//            foreach (var instanceName in instanceKey.GetValueNames())  
//            {  
//                Console.WriteLine(ServerName + "\\" + instanceName);  
//            }  
//        }  
//    }  
//} 
